package imc.atividade.controller;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class controller {

    @GetMapping("/imc")
    public double calculadora(@RequestParam("peso") int peso, @RequestParam("altura") float altura) {

        double indice = peso / Math.pow(altura , 2);

        double banana = Math.round(indice);

        if (banana < 18.5) {
            return Double.parseDouble("Você está abaixo do peso, seu imc é: " + banana);
        }    else if (banana >= 18.5 && banana <= 24.9){
            return Double.parseDouble("Seu peso está normal, seu imc é: " + banana);
        }    else if (banana >= 25 && banana <= 29.9){
            return Double.parseDouble("Você está com sobrepeso, seu imc é: " + banana);
        }    else if (banana >= 30 && banana <= 34.9){
            return Double.parseDouble("Você está com obesidade classe I, seu imc é: " + banana);
        }    else if (banana >= 35 && banana <= 39.9){
            return Double.parseDouble("Você está com obesidade classe II, seu imc é: " + banana);
        }    else if (banana >= 40) {
            return Double.parseDouble("Você está com obesidade classe III, seu imc é: " + banana);
        }    else {
            return Double.parseDouble("Valor inválido. Tente novamente.");
        }
    }
}
